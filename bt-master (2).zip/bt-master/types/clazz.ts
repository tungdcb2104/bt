export interface Clazz {
  id: number
  name: string
  description: string
} 